export class CreateInmuebleDto {}
