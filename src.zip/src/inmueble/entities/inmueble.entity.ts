export class Inmueble {}
